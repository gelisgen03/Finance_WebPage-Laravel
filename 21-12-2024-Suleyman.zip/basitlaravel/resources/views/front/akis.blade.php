<div id="akis" class="container-fluid content">
    <div class="row">
    <h2>Akış İçeriği</h2>
    <p>Bu bölümde akışla ilgili bilgiler yer alır.</p>
    </div>
    

</div>