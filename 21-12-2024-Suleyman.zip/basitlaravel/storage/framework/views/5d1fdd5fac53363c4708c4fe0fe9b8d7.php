<div id="akis" class="container-fluid content">
    <div class="row">
    <h2>Akış İçeriği</h2>
    <p>Bu bölümde akışla ilgili bilgiler yer alır.</p>
    </div>
    

</div><?php /**PATH C:\Users\gelis\Desktop\KismiZamanli\basitlaravel\resources\views/front/akis.blade.php ENDPATH**/ ?>