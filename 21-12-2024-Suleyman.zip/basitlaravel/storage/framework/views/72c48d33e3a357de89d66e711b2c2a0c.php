
    <!-- Topbar Navigasyon (bulunulann sayfa)-->
   
    <div style="background-color: rgb(0, 0, 0); margin:1%">
        <div style="display:flex; flex-direction: column ">
        <!--Sayfa Yer bildirimi -->
            <div style="float:inline-start ">
                <a class="nav-link" href="index.html">
                    <i style="color:gray" class="fas fa-fw fa-Home"></i>
                    <span style="color:gray"><?php echo e($ustsayfadata->bulunulanSayfaAdi); ?></span></a>
                    <!-- Divider -->
            <hr style="border-top: 2px solid #bbb;">
        
    </div> 
            <!--FON ADI -->
            <div class="text-2xl font-semibold">
                <div class="sidebar-brand-text mx-3" style="display:grid">
                    <!-- Resim + FonAdı + Diğer bilgiler için tablo -->
                    <table border="0" style="border-collapse:separate; border-spacing:px  ">
                        <tr style="display:block">
                            <!-- Resim Sütünu-->
                            <td rowspan="2"  >
                                <div style="float:inline-start;display:flex" class="">
                                    <img  alt="Fintables Logo" loading="lazy" width="65" height="65" data-nimg="1" style="color:transparent" src="/img/fintableslogo.svg">
                                </div>
                            </td>
                            <!-- Resmin Yanındaki yazının sütünu -->
                            <td style="width: 65%">  
                                    <span style="font-weight: bold;font-size:200%"><?php echo e($ustsayfadata->fonAdi); ?></span>
                                    <br>
                                    <span><?php echo e($ustsayfadata->fonAdiAltAciklama); ?></span>
                            </td>
                            <!--Tarih Sütünu -->
                            <td style="width: 10%" >
                                <span  style="font-size:100%; font-family:Arial, Helvetica, sans-serif  "><?php echo e($ustsayfadata->guncelTarih); ?></span>
                                <br>
                                <span style="color:white;font-size:150%"><?php echo e($ustsayfadata->guncelTarihData); ?> </span>
                            </td>
                            <!--1 Aylık Getiti Sütünu -->
                            <td style="text-align: center;width: 10%">
                                <span style="font-size:100%">1 Aylık Getiri</span>
                                <br>
                                <span style="font-size:110%"><?php echo e($ustsayfadata->birAylikGetitiData); ?></span>
                                
                            </td>
                            <!--3 Aylık getiti sütünu -->
                            <td style="text-align: center;width:10%">
                                
                                <span style="font-size:100%">3 Aylık Getiri</span>
                                <br>
                                <span style="font-size:110%"><?php echo e($ustsayfadata->ucAylikGetitiData); ?></span>
                            </td>
                        </tr>
                        
                    </table>
                    
                    
                </div>      
        </div>
<br>    <?php /**PATH C:\Users\gelis\Documents\GitHub\Finance_WebPage-Laravel\basitlaravel\resources\views/front/ustSayfaYazilari.blade.php ENDPATH**/ ?>