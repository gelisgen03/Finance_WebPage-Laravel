
<div  id="rakip" class="container-fluid content">
    <h2>Rakip Analizi İçeriği</h2>
    <p>Bu bölümde Rakip analizi ilgili bilgiler yer alır.</p>
</div>
<?php /**PATH C:\Users\gelis\Desktop\KismiZamanli\basitlaravel\resources\views/front/rakipAnalizi.blade.php ENDPATH**/ ?>