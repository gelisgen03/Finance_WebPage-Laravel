

    <div id="righWrapper" style="position:fixed  ; top: 0; right: 0; width: 3%; height: 90%; display: flex; flex-direction: column; background-color: rgb(0, 0, 0);margin-left:10% ">
        <div class="">
             <!--Favoriler icon -->
            <br>
            <center>
                <div >
                    <a class="nav-item" href="index.html">
                        <i title="Favoriler" style="color:gray;" class="fa fa-list-alt"></i>
                </div>
            </center>
            <br>
            <!--Piyasalar icon -->
            <center>
                <div>
                    <a class="nav-item" href="index.html">
                        <i title="Piyasalar" style="color:gray" class="fa fa-signal"></i>
                </div>
            </center>
            <br>
            <!--Notlar icon -->
            <center>
            <div>
                    <a class="nav-item" href="index.html">
                        <i title="Notlar" style="color:gray" class="fa fa-file"></i>
            </div>
            </center>
            <br>
            <!--Alarmlar icon -->
            <center>
            <div>
                <a class="nav-item" href="index.html">
                    <i title="Alarmlar" style="color:gray" class="fa fa-clock"></i>
            </div>
            </center>
            <br>
            <!-- Cüzdan icon -->
            <center>
            <div>
                <a class="nav-item" href="index.html">
                    <i style="color:gray" class="fa fa-credit-card"></i>
            </div>
            </center> 
            </div>
    </div>

<!-- End of Righ Wrapper --><?php /**PATH C:\Users\gelis\Desktop\KismiZamanli\basitlaravel\resources\views/front/rightWrapper.blade.php ENDPATH**/ ?>